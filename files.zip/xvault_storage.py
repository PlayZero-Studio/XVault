#!/usr/bin/env python3
"""
xvault_storage.py - Motor de una bóveda XVault.

Cada bóveda es una carpeta con:
    vault.meta      <- SIN cifrar: sal, iteraciones del KDF, nombre, pista
                        (la pista es de la CONTRASEÑA DE LA BÓVEDA, no por
                        archivo -tiene más sentido en un producto
                        multi-bóveda: te ayuda a recordar CUÁL contraseña
                        usar para ESTA bóveda en particular)
    items.enc       <- índice cifrado: nombre original, etiquetas,
                        favorito, tamaño, fecha, por cada archivo guardado
    objects/<id>.enc <- contenido cifrado de cada archivo (AES-256-GCM,
                        clave única por archivo vía HKDF desde la clave
                        maestra de la bóveda)

BACKUP AUTOMÁTICO CIFRADO:
Como todo lo anterior YA está cifrado en disco, hacer backup es simplemente
espejar la carpeta de la bóveda a otra ubicación (por ejemplo, una carpeta
de OneDrive/Google Drive que el usuario ya sincroniza) — sin descifrar nada
en el proceso. Si falla (carpeta no disponible, sin permisos, etc.) NO debe
interrumpir el uso normal de la bóveda: se avisa, pero no se corta nada.
"""
import os
import json
import time
import shutil
import secrets
import threading
import uuid
from pathlib import Path

import xvault_crypto


class WrongPasswordError(Exception):
    pass


class VaultCorruptedError(Exception):
    pass


class ItemNotFoundError(Exception):
    pass


class XVault:
    ITEMS_MAGIC = b"XVI1"

    def __init__(self, vault_dir, password: str, name: str = None, hint: str = ""):
        self.vault_dir = Path(vault_dir)
        self.objects_dir = self.vault_dir / "objects"
        self.meta_path = self.vault_dir / "vault.meta"
        self.items_path = self.vault_dir / "items.enc"
        self.lock = threading.RLock()
        self.backup_dir = None

        if self.meta_path.exists():
            meta = json.loads(self.meta_path.read_text(encoding="utf-8"))
            salt = bytes.fromhex(meta["salt"])
            self.name = meta.get("name", self.vault_dir.name)
            self.hint = meta.get("hint", "")
            self.backup_dir = meta.get("backup_dir") or None
            self.master_key = xvault_crypto.derive_master_key(password, salt)
            self._load_items()
        else:
            self.vault_dir.mkdir(parents=True, exist_ok=True)
            self.objects_dir.mkdir(exist_ok=True)
            salt = xvault_crypto.new_salt()
            self.name = name or self.vault_dir.name
            self.hint = hint or ""
            self.meta_path.write_text(json.dumps({
                "version": 1,
                "salt": salt.hex(),
                "iterations": xvault_crypto.KDF_ITERATIONS,
                "name": self.name,
                "hint": self.hint,
                "backup_dir": None,
                "created": time.time(),
            }), encoding="utf-8")
            self.master_key = xvault_crypto.derive_master_key(password, salt)
            self.items = {}
            self._save_items()

    # -- persistencia del índice -------------------------------------------------
    def _load_items(self):
        if not self.items_path.exists():
            self.items = {}
            return
        data = self.items_path.read_bytes()
        if data[:4] != self.ITEMS_MAGIC:
            raise VaultCorruptedError("items.enc con cabecera inválida.")
        try:
            payload = xvault_crypto.decrypt_bytes(self.master_key, data[4:])
        except Exception as e:
            raise WrongPasswordError("Contraseña incorrecta para esta bóveda.") from e
        self.items = json.loads(payload.decode("utf-8"))

    def _save_items(self):
        payload = json.dumps(self.items).encode("utf-8")
        frame = xvault_crypto.encrypt_bytes(self.master_key, payload)
        tmp = str(self.items_path) + ".tmp"
        with open(tmp, "wb") as f:
            f.write(self.ITEMS_MAGIC)
            f.write(frame)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, self.items_path)
        self._run_backup_if_configured()

    def _save_meta(self):
        meta = json.loads(self.meta_path.read_text(encoding="utf-8"))
        meta["name"] = self.name
        meta["hint"] = self.hint
        meta["backup_dir"] = self.backup_dir
        tmp = str(self.meta_path) + ".tmp"
        Path(tmp).write_text(json.dumps(meta), encoding="utf-8")
        os.replace(tmp, self.meta_path)

    # -- items: agregar / extraer / eliminar -------------------------------------------------
    def add_file(self, source_path: str, tags=None, favorite=False) -> str:
        with self.lock:
            source_path = str(source_path)
            item_id = uuid.uuid4().hex
            item_key = xvault_crypto.derive_item_key(self.master_key, bytes.fromhex(item_id))

            with open(source_path, "rb") as f:
                plaintext = f.read()
            frame = xvault_crypto.encrypt_bytes(item_key, plaintext)

            obj_path = self.objects_dir / f"{item_id}.enc"
            with open(obj_path, "wb") as f:
                f.write(frame)
                f.flush()
                os.fsync(f.fileno())

            self.items[item_id] = {
                "name": os.path.basename(source_path),
                "tags": list(tags or []),
                "favorite": bool(favorite),
                "size": len(plaintext),
                "added": time.time(),
            }
            self._save_items()
            return item_id

    def extract_file(self, item_id: str, dest_dir: str) -> str:
        with self.lock:
            item = self.items.get(item_id)
            if item is None:
                raise ItemNotFoundError(item_id)
            item_key = xvault_crypto.derive_item_key(self.master_key, bytes.fromhex(item_id))
            obj_path = self.objects_dir / f"{item_id}.enc"
            frame = obj_path.read_bytes()
            plaintext = xvault_crypto.decrypt_bytes(item_key, frame)

            dest_dir = Path(dest_dir)
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest_path = dest_dir / item["name"]
            base, ext = os.path.splitext(str(dest_path))
            counter = 1
            while dest_path.exists():
                dest_path = Path(f"{base} ({counter}){ext}")
                counter += 1

            dest_path.write_bytes(plaintext)
            return str(dest_path)

    def delete_item(self, item_id: str):
        with self.lock:
            if item_id not in self.items:
                raise ItemNotFoundError(item_id)
            obj_path = self.objects_dir / f"{item_id}.enc"
            try:
                os.remove(obj_path)
            except FileNotFoundError:
                pass
            del self.items[item_id]
            self._save_items()

    # -- etiquetas / favoritos -------------------------------------------------
    def set_tags(self, item_id: str, tags):
        with self.lock:
            if item_id not in self.items:
                raise ItemNotFoundError(item_id)
            self.items[item_id]["tags"] = list(tags)
            self._save_items()

    def toggle_favorite(self, item_id: str) -> bool:
        with self.lock:
            if item_id not in self.items:
                raise ItemNotFoundError(item_id)
            self.items[item_id]["favorite"] = not self.items[item_id].get("favorite", False)
            self._save_items()
            return self.items[item_id]["favorite"]

    def all_tags(self):
        tags = set()
        for item in self.items.values():
            tags.update(item.get("tags", []))
        return sorted(tags)

    # -- búsqueda -------------------------------------------------
    def search(self, query: str = "", tag: str = None, only_favorites: bool = False):
        query = (query or "").strip().lower()
        results = []
        for item_id, item in self.items.items():
            if only_favorites and not item.get("favorite", False):
                continue
            if tag and tag not in item.get("tags", []):
                continue
            if query and query not in item["name"].lower():
                continue
            results.append((item_id, item))
        results.sort(key=lambda pair: pair[1]["added"], reverse=True)
        return results

    # -- backup automático cifrado -------------------------------------------------
    def set_backup_dir(self, backup_dir):
        with self.lock:
            self.backup_dir = str(backup_dir) if backup_dir else None
            self._save_meta()
            if self.backup_dir:
                self._run_backup_if_configured()

    def _run_backup_if_configured(self):
        if not self.backup_dir:
            return None
        try:
            return self._mirror_to(self.backup_dir)
        except Exception as e:
            self.last_backup_error = str(e)
            return False

    def _mirror_to(self, backup_dir):
        """Copia (espejo) los archivos NUEVOS o MODIFICADOS de la bóveda hacia
        backup_dir. Como todo ya está cifrado en disco, esto es una simple
        copia de archivos -no hay que descifrar ni volver a cifrar nada."""
        backup_dir = Path(backup_dir)
        backup_dir.mkdir(parents=True, exist_ok=True)
        backup_objects = backup_dir / "objects"
        backup_objects.mkdir(exist_ok=True)

        copied = 0
        for src in (self.meta_path, self.items_path):
            if src.exists():
                dst = backup_dir / src.name
                if self._needs_copy(src, dst):
                    shutil.copy2(src, dst)
                    copied += 1

        if self.objects_dir.exists():
            for src in self.objects_dir.iterdir():
                dst = backup_objects / src.name
                if self._needs_copy(src, dst):
                    shutil.copy2(src, dst)
                    copied += 1

        self.last_backup_error = None
        self.last_backup_time = time.time()
        return copied

    @staticmethod
    def _needs_copy(src: Path, dst: Path) -> bool:
        if not dst.exists():
            return True
        s, d = src.stat(), dst.stat()
        return s.st_size != d.st_size or s.st_mtime > d.st_mtime + 1

    def close(self):
        with self.lock:
            self._save_items()
