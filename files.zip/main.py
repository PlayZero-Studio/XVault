#!/usr/bin/env python3
"""
XVault - Gestor de bóvedas cifradas, con múltiples bóvedas, búsqueda por
etiquetas/favoritos, y backup automático cifrado.

Proyecto independiente de MVault (mismo algoritmo de derivación de clave,
implementación propia — ver xvault_crypto.py).
"""
import os
import time
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, simpledialog

import xvault_registry
from xvault_storage import XVault, WrongPasswordError, ItemNotFoundError

# ---------------------------------------------------------------------------
# Paleta (mismo lenguaje visual que MVault, un escalón más pulido)
# ---------------------------------------------------------------------------
BG = "#0c0e14"
BG_CARD = "#161924"
BG_CARD_HOVER = "#1d2130"
BG_INPUT = "#1f2330"
BORDER = "#262b3a"
ACCENT = "#8b6cff"
ACCENT_HOVER = "#a086ff"
ACCENT_DARK = "#6c4fe0"
GOLD = "#f5c451"       # detalle "premium"
TEXT_PRIMARY = "#f5f5fa"
TEXT_SECONDARY = "#9497a8"
TEXT_MUTED = "#5c6070"
DANGER = "#ff5c7a"
SUCCESS = "#2fd3a5"


def lerp_color(c1, c2, t):
    """Interpola linealmente entre dos colores hex, para animaciones suaves."""
    c1 = c1.lstrip("#"); c2 = c2.lstrip("#")
    r1, g1, b1 = int(c1[0:2], 16), int(c1[2:4], 16), int(c1[4:6], 16)
    r2, g2, b2 = int(c2[0:2], 16), int(c2[2:4], 16), int(c2[4:6], 16)
    r = round(r1 + (r2 - r1) * t)
    g = round(g1 + (g2 - g1) * t)
    b = round(b1 + (b2 - b1) * t)
    return f"#{r:02x}{g:02x}{b:02x}"


class AnimatedButton(tk.Canvas):
    """Botón redondeado con transición de color suave al pasar el mouse
    (varios pasos interpolados en vez de un cambio brusco)."""

    def __init__(self, parent, text, command, color, hover_color,
                 width=320, height=44, fg="#0c0e14", outline=False, **kwargs):
        super().__init__(parent, width=width, height=height, bg=BG,
                          highlightthickness=0, **kwargs)
        self.command = command
        self.color = color
        self.hover_color = hover_color
        self.fg = fg
        self.width = width
        self.height = height
        self.text = text
        self.outline = outline
        self.disabled = False
        self._anim_job = None
        self._current_color = color

        self._draw(color)
        self.bind("<Enter>", lambda _e: self._animate_to(self.hover_color))
        self.bind("<Leave>", lambda _e: self._animate_to(self.color))
        self.bind("<Button-1>", self._on_click)

    def _draw(self, color):
        self.delete("all")
        r = self.height / 2
        w, h = self.width, self.height
        kwargs = dict(fill=BG if self.outline else color, outline=color, width=1.5)
        self.create_arc(0, 0, r * 2, h, start=90, extent=180, **kwargs)
        self.create_arc(w - r * 2, 0, w, h, start=270, extent=180, **kwargs)
        self.create_rectangle(r, 0, w - r, h, **kwargs)
        text_color = color if self.outline else self.fg
        self.create_text(w / 2, h / 2, text=self.text, fill=text_color,
                          font=("Segoe UI", 11, "bold"))

    def _animate_to(self, target_color, steps=8, i=0, start_color=None):
        if self.disabled:
            return
        if self._anim_job:
            self.after_cancel(self._anim_job)
        if i == 0:
            start_color = self._current_color
        t = (i + 1) / steps
        self._current_color = lerp_color(start_color, target_color, min(t, 1.0))
        self._draw(self._current_color)
        if i < steps - 1:
            self._anim_job = self.after(12, lambda: self._animate_to(target_color, steps, i + 1, start_color))
        else:
            self._current_color = target_color

    def _on_click(self, _e):
        if not self.disabled and self.command:
            self.command()

    def set_enabled(self, enabled: bool):
        self.disabled = not enabled
        color = self.color if enabled else "#2a2d3a"
        self._current_color = color
        self._draw(color)
        self.config(cursor="hand2" if enabled else "arrow")


class Toast(tk.Frame):
    """Notificación tipo 'toast' que aparece deslizándose y se auto-oculta."""

    def __init__(self, parent):
        super().__init__(parent, bg=BG_CARD, highlightbackground=BORDER, highlightthickness=1)
        self.parent = parent
        self.label = tk.Label(self, font=("Segoe UI", 9), bg=BG_CARD, fg=TEXT_PRIMARY,
                               padx=16, pady=10, wraplength=360, justify="left")
        self.label.pack()
        self._hide_job = None

    def show(self, text, kind="info", duration=3200):
        color = {"success": SUCCESS, "error": DANGER, "info": TEXT_PRIMARY}.get(kind, TEXT_PRIMARY)
        self.label.config(text=text, fg=color)
        self.place(relx=0.5, rely=1.0, anchor="s", y=-20)
        self.lift()
        if self._hide_job:
            self.after_cancel(self._hide_job)
        self._hide_job = self.after(duration, self.hide)

    def hide(self):
        self.place_forget()


class PasswordDialog(tk.Toplevel):
    def __init__(self, parent, title, confirm=False, ask_hint=False, ask_name=False, show_hint=None):
        super().__init__(parent)
        self.title(title)
        self.configure(bg=BG_CARD)
        self.resizable(False, False)
        self.result = None
        self.hint_result = ""
        self.name_result = ""
        self.confirm = confirm

        self.transient(parent)
        self.grab_set()

        h = 230
        if ask_name: h += 60
        if confirm: h += 30
        if ask_hint: h += 70
        if show_hint: h += 50
        w = 380
        self.geometry(f"{w}x{h}")
        self.update_idletasks()
        px = parent.winfo_rootx() + (parent.winfo_width() - w) // 2
        py = parent.winfo_rooty() + (parent.winfo_height() - h) // 2
        self.geometry(f"+{max(px,0)}+{max(py,0)}")

        pad = tk.Frame(self, bg=BG_CARD)
        pad.pack(fill="both", expand=True, padx=22, pady=18)

        tk.Label(pad, text=title, font=("Segoe UI", 13, "bold"), bg=BG_CARD,
                 fg=TEXT_PRIMARY, anchor="w").pack(fill="x")

        if show_hint:
            box = tk.Frame(pad, bg="#232842")
            box.pack(fill="x", pady=(10, 0))
            tk.Label(box, text=f"💡 Pista: {show_hint}", font=("Segoe UI", 9),
                     bg="#232842", fg=TEXT_PRIMARY, anchor="w", wraplength=320,
                     justify="left").pack(fill="x", padx=10, pady=8)

        self.name_entry = None
        if ask_name:
            self.name_entry = self._entry(pad, "Nombre de la bóveda")

        self.entry1 = self._entry(pad, "Contraseña")
        self.entry2 = None
        if confirm:
            self.entry2 = self._entry(pad, "Confirmar contraseña")

        self.hint_entry = None
        if ask_hint:
            tk.Label(pad, text="Pista de la contraseña (opcional, se guarda sin cifrar)",
                     font=("Segoe UI", 8), bg=BG_CARD, fg=TEXT_MUTED, anchor="w").pack(fill="x", pady=(10, 3))
            self.hint_entry = tk.Entry(pad, font=("Segoe UI", 10), bg=BG_INPUT, fg=TEXT_PRIMARY,
                                        insertbackground=TEXT_PRIMARY, relief="flat",
                                        highlightthickness=1, highlightbackground=BORDER, highlightcolor=ACCENT)
            self.hint_entry.pack(fill="x", ipady=5)

        self.show_var = tk.BooleanVar(value=False)
        toggle = tk.Checkbutton(pad, text="Mostrar contraseña", variable=self.show_var,
                                 command=self._toggle_show, bg=BG_CARD, fg=TEXT_SECONDARY,
                                 selectcolor=BG_CARD, activebackground=BG_CARD,
                                 activeforeground=TEXT_PRIMARY, font=("Segoe UI", 8),
                                 highlightthickness=0, bd=0)
        toggle.pack(anchor="w", pady=(10, 8))

        btn_frame = tk.Frame(pad, bg=BG_CARD)
        btn_frame.pack(fill="x", side="bottom")
        tk.Label(btn_frame, text="Cancelar", font=("Segoe UI", 10), bg=BG_CARD,
                 fg=TEXT_SECONDARY, cursor="hand2").pack(side="left")
        btn_frame.winfo_children()[0].bind("<Button-1>", lambda _e: self._cancel())
        ok_lbl = tk.Label(btn_frame, text="Aceptar  →", font=("Segoe UI", 10, "bold"),
                           bg=BG_CARD, fg=ACCENT, cursor="hand2")
        ok_lbl.pack(side="right")
        ok_lbl.bind("<Button-1>", lambda _e: self._accept())

        self.bind("<Return>", lambda _e: self._accept())
        self.bind("<Escape>", lambda _e: self._cancel())
        (self.name_entry or self.entry1).focus_set()
        self.wait_window(self)

    def _entry(self, parent, placeholder):
        tk.Label(parent, text=placeholder, font=("Segoe UI", 8), bg=BG_CARD,
                 fg=TEXT_MUTED, anchor="w").pack(fill="x", pady=(10, 3))
        show = "" if placeholder == "Nombre de la bóveda" else "*"
        entry = tk.Entry(parent, show=show, font=("Segoe UI", 11), bg=BG_INPUT, fg=TEXT_PRIMARY,
                          insertbackground=TEXT_PRIMARY, relief="flat", highlightthickness=1,
                          highlightbackground=BORDER, highlightcolor=ACCENT)
        entry.pack(fill="x", ipady=6)
        return entry

    def _toggle_show(self):
        char = "" if self.show_var.get() else "*"
        self.entry1.config(show=char)
        if self.entry2:
            self.entry2.config(show=char)

    def _accept(self):
        if self.name_entry is not None:
            name = self.name_entry.get().strip()
            if not name:
                self.name_entry.config(highlightbackground=DANGER)
                return
            self.name_result = name

        pwd = self.entry1.get()
        if not pwd:
            self.entry1.config(highlightbackground=DANGER)
            return
        if self.confirm:
            pwd2 = self.entry2.get()
            if pwd != pwd2:
                self.entry2.config(highlightbackground=DANGER)
                messagebox.showerror("Error", "Las contraseñas no coinciden.", parent=self)
                return
        if self.hint_entry is not None:
            self.hint_result = self.hint_entry.get()
        self.result = pwd
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()


class VaultCard(tk.Frame):
    """Tarjeta de una bóveda en el selector, con transición de color al hover."""

    def __init__(self, parent, name, path, on_click, **kwargs):
        super().__init__(parent, bg=BG_CARD, highlightbackground=BORDER,
                          highlightthickness=1, cursor="hand2", **kwargs)
        self.on_click = on_click
        inner = tk.Frame(self, bg=BG_CARD)
        inner.pack(fill="both", expand=True, padx=18, pady=16)

        top = tk.Frame(inner, bg=BG_CARD)
        top.pack(fill="x")
        icon = tk.Label(top, text="🔐", font=("Segoe UI Emoji", 20), bg=BG_CARD, fg=ACCENT)
        icon.pack(side="left")
        text_frame = tk.Frame(top, bg=BG_CARD)
        text_frame.pack(side="left", padx=(12, 0), fill="x", expand=True)
        title = tk.Label(text_frame, text=name, font=("Segoe UI", 12, "bold"),
                          bg=BG_CARD, fg=TEXT_PRIMARY, anchor="w")
        title.pack(fill="x")
        sub = tk.Label(text_frame, text=path, font=("Segoe UI", 8), bg=BG_CARD,
                        fg=TEXT_SECONDARY, anchor="w")
        sub.pack(fill="x")

        for w in (self, inner, top, icon, text_frame, title, sub):
            w.bind("<Button-1>", lambda _e: self.on_click())
            w.bind("<Enter>", self._on_enter)
            w.bind("<Leave>", self._on_leave)

    def _on_enter(self, _e):
        self.config(bg=BG_CARD_HOVER, highlightbackground=ACCENT)
        self._recolor(BG_CARD_HOVER)

    def _on_leave(self, _e):
        self.config(bg=BG_CARD, highlightbackground=BORDER)
        self._recolor(BG_CARD)

    def _recolor(self, color):
        def walk(w):
            try: w.config(bg=color)
            except tk.TclError: pass
            for c in w.winfo_children(): walk(c)
        walk(self)


# ---------------------------------------------------------------------------
# Aplicación principal
# ---------------------------------------------------------------------------
class XVaultApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("XVault")
        self.geometry("620x720")
        self.minsize(560, 640)
        self.configure(bg=BG)

        self.vault: XVault = None
        self.container = tk.Frame(self, bg=BG)
        self.container.pack(fill="both", expand=True)
        self.toast = Toast(self)

        self._show_selector_screen()

    # -- transición simple entre pantallas (slide) -------------------------------------------------
    def _switch_screen(self, build_fn):
        old = self.container
        new = tk.Frame(self, bg=BG)
        build_fn(new)
        new.place(x=self.winfo_width(), y=0, relwidth=1, relheight=1)
        self.container = new

        def step(i=0, total=10):
            frac = i / total
            new_x = int(self.winfo_width() * (1 - frac))
            new.place(x=new_x, y=0, relwidth=1, relheight=1)
            if i < total:
                self.after(10, lambda: step(i + 1, total))
            else:
                new.place(x=0, y=0, relwidth=1, relheight=1)
                old.destroy()

        step()

    # ======================================================================
    # PANTALLA 1: selector de bóvedas
    # ======================================================================
    def _show_selector_screen(self):
        def build(root):
            header = tk.Frame(root, bg=BG)
            header.pack(fill="x", padx=28, pady=(28, 18))
            title_row = tk.Frame(header, bg=BG)
            title_row.pack(fill="x")
            tk.Label(title_row, text="🗝️", font=("Segoe UI Emoji", 24), bg=BG, fg=GOLD).pack(side="left")
            tk.Label(title_row, text="XVault", font=("Segoe UI", 22, "bold"), bg=BG, fg=TEXT_PRIMARY).pack(side="left", padx=(8, 0))
            tk.Label(header, text="Tus bóvedas cifradas, todas en un solo lugar.",
                     font=("Segoe UI", 9), bg=BG, fg=TEXT_SECONDARY).pack(anchor="w", pady=(3, 0))

            list_zone = tk.Frame(root, bg=BG)
            list_zone.pack(fill="both", expand=True, padx=28, pady=(10, 0))

            vaults = xvault_registry.list_vaults()
            if not vaults:
                tk.Label(list_zone, text="Todavía no creaste ninguna bóveda.",
                         font=("Segoe UI", 10), bg=BG, fg=TEXT_MUTED).pack(pady=40)
            else:
                for v in vaults:
                    card = VaultCard(list_zone, v["name"], v["path"],
                                      lambda vv=v: self._open_vault_flow(vv))
                    card.pack(fill="x", pady=(0, 10))

            btn_zone = tk.Frame(root, bg=BG)
            btn_zone.pack(fill="x", padx=28, pady=(10, 28), side="bottom")
            AnimatedButton(btn_zone, "＋ Nueva bóveda", self._create_vault_flow,
                            ACCENT, ACCENT_HOVER, width=200).pack(anchor="w")

        self._switch_screen(build)

    def _create_vault_flow(self):
        dialog = PasswordDialog(self, "Nueva bóveda", confirm=True, ask_hint=True, ask_name=True)
        if not dialog.result:
            return
        name = dialog.name_result
        password = dialog.result
        hint = dialog.hint_result
        vault_dir = xvault_registry.default_vault_dir(name)
        try:
            vault = XVault(vault_dir, password, name=name, hint=hint)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo crear la bóveda: {e}")
            return
        xvault_registry.register_vault(name, str(vault_dir))
        self.vault = vault
        self._show_vault_screen()

    def _open_vault_flow(self, vault_entry):
        # Leemos la pista (si existe) sin necesitar la contraseña, del vault.meta sin cifrar
        import json
        from pathlib import Path
        hint = None
        meta_path = Path(vault_entry["path"]) / "vault.meta"
        if meta_path.exists():
            try:
                hint = json.loads(meta_path.read_text(encoding="utf-8")).get("hint") or None
            except Exception:
                hint = None

        dialog = PasswordDialog(self, f"Abrir '{vault_entry['name']}'", show_hint=hint)
        if not dialog.result:
            return
        try:
            vault = XVault(vault_entry["path"], dialog.result)
        except WrongPasswordError:
            messagebox.showerror("Error", "Contraseña incorrecta.")
            return
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo abrir la bóveda: {e}")
            return
        self.vault = vault
        self._show_vault_screen()

    # ======================================================================
    # PANTALLA 2: contenido de una bóveda (búsqueda, etiquetas, favoritos)
    # ======================================================================
    def _show_vault_screen(self):
        self._active_tag = None
        self._only_favorites = False

        def build(root):
            header = tk.Frame(root, bg=BG)
            header.pack(fill="x", padx=24, pady=(20, 10))

            top_row = tk.Frame(header, bg=BG)
            top_row.pack(fill="x")
            back_lbl = tk.Label(top_row, text="←", font=("Segoe UI", 14, "bold"), bg=BG,
                                 fg=TEXT_SECONDARY, cursor="hand2")
            back_lbl.pack(side="left")
            back_lbl.bind("<Button-1>", lambda _e: self._back_to_selector())
            tk.Label(top_row, text=self.vault.name, font=("Segoe UI", 16, "bold"),
                     bg=BG, fg=TEXT_PRIMARY).pack(side="left", padx=(10, 0))

            settings_lbl = tk.Label(top_row, text="⚙ Backup", font=("Segoe UI", 9, "underline"),
                                     bg=BG, fg=TEXT_SECONDARY, cursor="hand2")
            settings_lbl.pack(side="right")
            settings_lbl.bind("<Button-1>", lambda _e: self._backup_settings_flow())

            # -- búsqueda -------------------------------------------------
            search_row = tk.Frame(header, bg=BG)
            search_row.pack(fill="x", pady=(14, 0))
            self.search_var = tk.StringVar()
            search_entry = tk.Entry(search_row, textvariable=self.search_var, font=("Segoe UI", 10),
                                     bg=BG_INPUT, fg=TEXT_PRIMARY, insertbackground=TEXT_PRIMARY,
                                     relief="flat", highlightthickness=1, highlightbackground=BORDER,
                                     highlightcolor=ACCENT)
            search_entry.pack(fill="x", ipady=7)
            search_entry.insert(0, "")
            search_entry.bind("<KeyRelease>", lambda _e: self._refresh_item_list())
            self._search_entry_placeholder(search_entry, "Buscar por nombre...")

            # -- filtros: favoritos + etiquetas -------------------------------------------------
            filter_row = tk.Frame(header, bg=BG)
            filter_row.pack(fill="x", pady=(8, 0))
            self.fav_filter_lbl = tk.Label(filter_row, text="★ Favoritos", font=("Segoe UI", 8, "bold"),
                                            bg=BG_CARD, fg=TEXT_SECONDARY, cursor="hand2", padx=10, pady=4)
            self.fav_filter_lbl.pack(side="left", padx=(0, 6))
            self.fav_filter_lbl.bind("<Button-1>", lambda _e: self._toggle_fav_filter())

            self.tags_frame = tk.Frame(filter_row, bg=BG)
            self.tags_frame.pack(side="left", fill="x", expand=True)

            # -- lista de items -------------------------------------------------
            self.list_frame = tk.Frame(root, bg=BG)
            self.list_frame.pack(fill="both", expand=True, padx=24, pady=(14, 0))

            # -- agregar archivo -------------------------------------------------
            btn_zone = tk.Frame(root, bg=BG)
            btn_zone.pack(fill="x", padx=24, pady=(10, 20), side="bottom")
            AnimatedButton(btn_zone, "＋ Agregar archivo", self._add_file_flow,
                            ACCENT, ACCENT_HOVER, width=572).pack()

            self._render_tag_filters()
            self._refresh_item_list()

        self._switch_screen(build)

    def _search_entry_placeholder(self, entry, text):
        entry.insert(0, text)
        entry.config(fg=TEXT_MUTED)

        def on_focus_in(_e):
            if entry.get() == text:
                entry.delete(0, "end")
                entry.config(fg=TEXT_PRIMARY)

        def on_focus_out(_e):
            if not entry.get():
                entry.insert(0, text)
                entry.config(fg=TEXT_MUTED)

        entry.bind("<FocusIn>", on_focus_in)
        entry.bind("<FocusOut>", on_focus_out)

    def _back_to_selector(self):
        if self.vault:
            self.vault.close()
            self.vault = None
        self._show_selector_screen()

    def _render_tag_filters(self):
        for w in self.tags_frame.winfo_children():
            w.destroy()
        for tag in self.vault.all_tags():
            active = (tag == self._active_tag)
            lbl = tk.Label(self.tags_frame, text=f"#{tag}", font=("Segoe UI", 8),
                            bg=ACCENT if active else BG_CARD,
                            fg="#0c0e14" if active else TEXT_SECONDARY,
                            cursor="hand2", padx=8, pady=4)
            lbl.pack(side="left", padx=(0, 4))
            lbl.bind("<Button-1>", lambda _e, t=tag: self._toggle_tag_filter(t))

    def _toggle_tag_filter(self, tag):
        self._active_tag = None if self._active_tag == tag else tag
        self._render_tag_filters()
        self._refresh_item_list()

    def _toggle_fav_filter(self):
        self._only_favorites = not self._only_favorites
        self.fav_filter_lbl.config(bg=ACCENT if self._only_favorites else BG_CARD,
                                    fg="#0c0e14" if self._only_favorites else TEXT_SECONDARY)
        self._refresh_item_list()

    def _refresh_item_list(self):
        for w in self.list_frame.winfo_children():
            w.destroy()

        query = self.search_var.get()
        if query == "Buscar por nombre...":
            query = ""

        results = self.vault.search(query=query, tag=self._active_tag, only_favorites=self._only_favorites)

        if not results:
            tk.Label(self.list_frame, text="No hay archivos que coincidan.",
                     font=("Segoe UI", 9), bg=BG, fg=TEXT_MUTED).pack(pady=30)
            return

        canvas = tk.Canvas(self.list_frame, bg=BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.list_frame, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=BG)
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw", width=560)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        for item_id, item in results:
            self._build_item_row(inner, item_id, item)

    def _build_item_row(self, parent, item_id, item):
        row = tk.Frame(parent, bg=BG_CARD, highlightbackground=BORDER, highlightthickness=1)
        row.pack(fill="x", pady=(0, 8))
        inner = tk.Frame(row, bg=BG_CARD)
        inner.pack(fill="x", padx=14, pady=10)

        top = tk.Frame(inner, bg=BG_CARD)
        top.pack(fill="x")

        fav = item.get("favorite", False)
        star = tk.Label(top, text="★" if fav else "☆", font=("Segoe UI", 12),
                         bg=BG_CARD, fg=GOLD if fav else TEXT_MUTED, cursor="hand2")
        star.pack(side="left")
        star.bind("<Button-1>", lambda _e: self._toggle_fav(item_id))

        name_lbl = tk.Label(top, text=item["name"], font=("Segoe UI", 10, "bold"),
                             bg=BG_CARD, fg=TEXT_PRIMARY, anchor="w")
        name_lbl.pack(side="left", padx=(8, 0), fill="x", expand=True)

        size_kb = item.get("size", 0) / 1024
        size_lbl = tk.Label(top, text=f"{size_kb:.1f} KB", font=("Segoe UI", 8),
                             bg=BG_CARD, fg=TEXT_MUTED)
        size_lbl.pack(side="right")

        if item.get("tags"):
            tags_row = tk.Frame(inner, bg=BG_CARD)
            tags_row.pack(fill="x", pady=(6, 0))
            for t in item["tags"]:
                tk.Label(tags_row, text=f"#{t}", font=("Segoe UI", 7), bg=BG_INPUT,
                         fg=TEXT_SECONDARY, padx=6, pady=2).pack(side="left", padx=(0, 4))

        actions = tk.Frame(inner, bg=BG_CARD)
        actions.pack(fill="x", pady=(8, 0))
        extract_lbl = tk.Label(actions, text="⬇ Extraer", font=("Segoe UI", 8, "bold"),
                                bg=BG_CARD, fg=ACCENT, cursor="hand2")
        extract_lbl.pack(side="left")
        extract_lbl.bind("<Button-1>", lambda _e: self._extract_item_flow(item_id))

        tags_lbl = tk.Label(actions, text="🏷 Etiquetas", font=("Segoe UI", 8, "bold"),
                             bg=BG_CARD, fg=TEXT_SECONDARY, cursor="hand2")
        tags_lbl.pack(side="left", padx=(14, 0))
        tags_lbl.bind("<Button-1>", lambda _e: self._edit_tags_flow(item_id))

        del_lbl = tk.Label(actions, text="Eliminar", font=("Segoe UI", 8, "bold"),
                            bg=BG_CARD, fg=DANGER, cursor="hand2")
        del_lbl.pack(side="right")
        del_lbl.bind("<Button-1>", lambda _e: self._delete_item_flow(item_id, item["name"]))

    # -- acciones -------------------------------------------------
    def _add_file_flow(self):
        path = filedialog.askopenfilename(title="Elegí un archivo para agregar a la bóveda")
        if not path:
            return
        try:
            self.vault.add_file(path)
            self.toast.show(f"✅ Agregado: {os.path.basename(path)}", "success")
            self._render_tag_filters()
            self._refresh_item_list()
        except Exception as e:
            self.toast.show(f"⚠️ No se pudo agregar: {e}", "error")

    def _extract_item_flow(self, item_id):
        dest = filedialog.askdirectory(title="¿Dónde guardar el archivo?")
        if not dest:
            return
        try:
            result_path = self.vault.extract_file(item_id, dest)
            self.toast.show(f"✅ Extraído en:\n{result_path}", "success")
        except Exception as e:
            self.toast.show(f"⚠️ No se pudo extraer: {e}", "error")

    def _delete_item_flow(self, item_id, name):
        if messagebox.askyesno("Eliminar", f"¿Eliminar '{name}' de la bóveda?"):
            try:
                self.vault.delete_item(item_id)
                self.toast.show("🗑️ Eliminado.", "info")
                self._render_tag_filters()
                self._refresh_item_list()
            except Exception as e:
                self.toast.show(f"⚠️ No se pudo eliminar: {e}", "error")

    def _toggle_fav(self, item_id):
        try:
            self.vault.toggle_favorite(item_id)
            self._refresh_item_list()
        except Exception as e:
            self.toast.show(f"⚠️ {e}", "error")

    def _edit_tags_flow(self, item_id):
        current = self.vault.items[item_id].get("tags", [])
        new_tags_str = simpledialog.askstring(
            "Etiquetas", "Etiquetas separadas por coma:", initialvalue=", ".join(current), parent=self
        )
        if new_tags_str is None:
            return
        tags = [t.strip() for t in new_tags_str.split(",") if t.strip()]
        self.vault.set_tags(item_id, tags)
        self._render_tag_filters()
        self._refresh_item_list()

    def _backup_settings_flow(self):
        current = self.vault.backup_dir or ""
        msg = f"Carpeta de backup actual:\n{current or '(sin configurar)'}\n\n¿Elegir otra carpeta?"
        if not messagebox.askyesno("Backup automático", msg):
            return
        folder = filedialog.askdirectory(title="Elegí la carpeta de backup (ej: tu carpeta de OneDrive)")
        if not folder:
            return
        self.vault.set_backup_dir(folder)
        if self.vault.last_backup_error:
            self.toast.show(f"⚠️ Backup configurado, pero falló: {self.vault.last_backup_error}", "error")
        else:
            self.toast.show("✅ Backup automático configurado y sincronizado.", "success")


if __name__ == "__main__":
    app = XVaultApp()
    app.mainloop()
