#!/usr/bin/env python3
"""
xvault_registry.py - Lista de bóvedas conocidas por XVault.

Este archivo NO contiene información sensible: solo nombres y rutas de
carpetas de bóveda (cada bóveda protege su propio contenido con su propia
contraseña). Vive sin cifrar porque hace falta poder mostrar la lista de
bóvedas ANTES de que el usuario elija cuál abrir y con qué contraseña.
"""
import json
import os
import sys
import time
from pathlib import Path

if sys.platform == "win32" and os.environ.get("LOCALAPPDATA"):
    XVAULT_HOME = Path(os.environ["LOCALAPPDATA"]) / "XVault"
else:
    XVAULT_HOME = Path.home() / "XVault"

REGISTRY_PATH = XVAULT_HOME / "registry.json"


def _load():
    if not REGISTRY_PATH.exists():
        return {"vaults": []}
    try:
        return json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"vaults": []}


def _save(data):
    XVAULT_HOME.mkdir(parents=True, exist_ok=True)
    tmp = str(REGISTRY_PATH) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, REGISTRY_PATH)


def list_vaults():
    return _load()["vaults"]


def register_vault(name: str, path: str):
    data = _load()
    for v in data["vaults"]:
        if v["path"] == str(path):
            return v
    entry = {"name": name, "path": str(path), "created": time.time()}
    data["vaults"].append(entry)
    _save(data)
    return entry


def unregister_vault(path: str):
    data = _load()
    data["vaults"] = [v for v in data["vaults"] if v["path"] != str(path)]
    _save(data)


def rename_vault(path: str, new_name: str):
    data = _load()
    for v in data["vaults"]:
        if v["path"] == str(path):
            v["name"] = new_name
    _save(data)


def default_vault_dir(name: str) -> Path:
    safe = "".join(c for c in name if c.isalnum() or c in (" ", "-", "_")).strip() or "Boveda"
    base = XVAULT_HOME / "vaults" / safe
    candidate = base
    counter = 2
    existing_paths = {v["path"] for v in list_vaults()}
    while str(candidate) in existing_paths or candidate.exists():
        candidate = XVAULT_HOME / "vaults" / f"{safe} ({counter})"
        counter += 1
    return candidate
