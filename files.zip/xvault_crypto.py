#!/usr/bin/env python3
"""
xvault_crypto.py - Primitivas criptográficas de XVault.

Reutiliza el MISMO algoritmo de derivación de clave que MVault
(PBKDF2-HMAC-SHA256, 390.000 iteraciones), replicado acá (no importado) para
mantener XVault como proyecto independiente sin acoplarse al archivo de
MVault. El resto es una mejora respecto a MVault: en vez de repetir PBKDF2
completo por cada archivo (costoso si importás varios de una), la clave
maestra se deriva UNA vez al abrir la bóveda, y cada archivo obtiene su
propia subclave vía HKDF (barato, y sin repetir nunca una clave entre
archivos). El cifrado en sí es AES-256-GCM (autenticado), de la misma
librería `cryptography` que ya usa MVault.
"""
import secrets
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

KDF_ITERATIONS = 390_000
SALT_SIZE = 16
NONCE_SIZE = 12


def derive_master_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=KDF_ITERATIONS)
    return kdf.derive(password.encode("utf-8"))


def derive_item_key(master_key: bytes, item_id: bytes) -> bytes:
    hkdf = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b"xvault-item-key:" + item_id)
    return hkdf.derive(master_key)


def encrypt_bytes(key: bytes, plaintext: bytes) -> bytes:
    nonce = secrets.token_bytes(NONCE_SIZE)
    return nonce + AESGCM(key).encrypt(nonce, plaintext, associated_data=None)


def decrypt_bytes(key: bytes, frame: bytes) -> bytes:
    nonce, ciphertext = frame[:NONCE_SIZE], frame[NONCE_SIZE:]
    return AESGCM(key).decrypt(nonce, ciphertext, associated_data=None)


def new_salt() -> bytes:
    return secrets.token_bytes(SALT_SIZE)
